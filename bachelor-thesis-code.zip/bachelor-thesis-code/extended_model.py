"""
- Implements extended spin chain model with NNNN interactions.
- Defines energy and gradient computation for the extended model.
- Enforces periodic boundary conditions during minimization.
- Calculates interaction coefficients and stationary points.
- Computes infimal energy bounds (upper, lower, asymptotic).
"""

from typing import Any
import numpy as np
from scipy.optimize import minimize


def compute_energy_extended_model(
    u: np.ndarray[Any, np.dtype[np.floating[Any]]], alpha: float, alpha2: float, n: int
) -> float:
    energy = 0
    angle_difference1 = u - np.roll(u, -1)
    angle_difference2 = u - np.roll(u, -2)
    angle_difference3 = u - np.roll(u, -3)
    energy1 = -alpha * np.cos(angle_difference1[: n - 2])
    energy2 = alpha2 * np.cos(angle_difference2[: n - 2])
    energy3 = np.cos(angle_difference3[: n - 2])
    energy = energy1.sum() + energy2.sum() + energy3.sum()
    energy /= n
    return energy


def compute_energy_gradient_extended_model(
    u: np.ndarray[Any, np.dtype[np.floating[Any]]], alpha: float, n: int
) -> np.ndarray[Any, Any]:
    energy_gradient = np.zeros_like(u)
    dif1 = u[: n - 1] - u[1:n]
    dif2 = u[: n - 1] - u[2:]
    energy_gradient[: n - 1] += alpha * np.sin(dif1)
    energy_gradient[1:n] -= alpha * np.sin(dif1)
    energy_gradient[: n - 1] -= np.sin(dif2)
    energy_gradient[2:] += np.sin(dif2)
    energy_gradient /= n
    return energy_gradient


def periodic_boundary_condition_extended_model(u):
    n = len(u) - 1
    dot1 = np.cos(u[0] - u[1])
    dot2 = np.cos(u[n - 2] - u[n - 1])
    dot3 = np.cos(u[1] - u[2])
    dot4 = np.cos(u[n - 1] - u[n])
    dot5 = np.cos(u[0] - u[2])
    dot6 = np.cos(u[n - 2] - u[n])
    bc1 = abs(dot1 - dot2)
    bc2 = abs(dot3 - dot4)
    bc3 = abs(dot5 - dot6)
    return bc1 + bc2 + bc3


def optimize_energy_extended_model(
    u: np.ndarray[Any, np.dtype[np.floating[Any]]],
    alpha1: float,
    alpha2: float,
    n: int,
    maxiter=10000,
    tolerance=1e-8,
    verbose=0,
) -> Any:
    constraint = {
        "type": "eq",
        "fun": lambda u: periodic_boundary_condition_extended_model(u),
    }

    res = minimize(
        fun=compute_energy_extended_model,
        x0=u,
        args=(alpha1, alpha2, n),
        method="SLSQP",
        jac=compute_energy_gradient_extended_model,
        constraints=[constraint],
        options={"maxiter": maxiter, "ftol": tolerance, "disp": verbose > 0},
    )

    # Warning if optimization might not have truly converged
    if not res.success or np.linalg.norm(res.jac) > 1e-6:
        print(
            f"Warning: E_{n} may not be a true minimum. Gradient norm = {np.linalg.norm(res.jac):.2e}"
        )
        print(f"Number of iterations = {res.nit}")
        print(f"Solver message: {res.message}")
    else:
        print("Optimization Succesful.")
    return res


def interaction_coefficients_extended_model(alpha1, alpha2):
    a = np.sqrt(alpha2**2 / 4 + alpha2 + alpha1)
    gamma_plus = alpha2 / 2 + a
    beta_plus = alpha2 / 2 - a
    return gamma_plus, beta_plus


def stationary_points_energy_plus_extended_model(alpha1, alpha2):
    d = np.sqrt(alpha2**2 + 3 * alpha1 + 9)
    x3 = (-alpha2 + d) / 6
    x4 = (-alpha2 - d) / 6
    return 1, -1, x3, x4


def estimated_characteristical_polynomial(alpha1, alpha2, n):
    gamma_plus, beta_plus = interaction_coefficients_extended_model(alpha1, alpha2)
    x1, x2, x3, x4 = stationary_points_energy_plus_extended_model(alpha1, alpha2)

    def g(x):
        return (
            1
            + gamma_plus**2 / 2
            + beta_plus**2 / 2
            - gamma_plus
            - beta_plus
            + x * (gamma_plus + beta_plus + gamma_plus * beta_plus - 3)
            + 2 * x**2 * (gamma_plus + beta_plus)
            + 4 * x**3
        )

    p_min_vals = []
    for t in range(n):
        x = np.cos(2 * np.pi * t / n)
        p = g(x)
        p_min_vals.append(p)

    if n == 0:
        p1, p2, p3, p4 = g(x1), g(x2), g(x3), g(x4)
        pmin = min(p1, p2, p3, p4)
    else:
        pmin = min(p_min_vals)
    return pmin


def compute_delta(alpha1, alpha2):
    return 1 + alpha2**2 / 2 + alpha2 + alpha1


def get_infimal_energy_bounds(
    alpha1: float, alpha2: float, n: 0 = int, bound=""
) -> float:
    p_min = estimated_characteristical_polynomial(alpha1, alpha2, n)
    a1, a2 = interaction_coefficients_extended_model(alpha1, alpha2)
    omega = compute_delta(alpha1, alpha2)
    if bound == "asymptotic" and n == 0:
        energy_bound = p_min - omega
    elif bound == "lower" and n >= 1:
        energy_bound1 = -omega * (1 - 2 / n)
        energy_bound2 = (p_min - omega) * (1 - 2 / n) - 1 / n * 3 / 2 * (
            2 + abs(a1) + abs(a2)
        ) ** 2
        energy_bound = max(energy_bound1, energy_bound2)
    elif bound == "upper" and n >= 1:
        energy_bound = (p_min - omega) * (1 - 2 / n)
    else:
        print(f"Invalid parameter combination (n,bound) = ({n}, {bound}). Abort...")
        exit()
    return energy_bound
