"""
Main source code of the Bachelor thesis 'On a Mathematical Model for One-Dimensional Frustrated Spin Chains: Gamma-Convergence and Numerics'.
Author: Leo Leander Roller.
Publication date on GitHub 07/2025.

This file implements the **numerical analysis and visualizations of the theoretical results proven in the thesis**, corresponding to Sections 4.3–4.5 of the text.

Specifically, the script:
- Numerically minimizes the discrete spin chain energy functional E_n described in Proposition 4.1 for varying system sizes n and different initialization strategies (random, perturbed, optimal).
- Validates and illustrates the Gamma-limit convergence results from Theorem 4.4 by comparing discrete minima with the continuum limit.
- Computes and visualizes the homogenized energy density f_hom and its numerical approximation according to the homogenization formula in Theorem 4.4.
- Analyzes chirality transitions by visualizing spin configurations and chirality flips, supporting the discussion in Section 4.4.
- Extends the numerical analysis to a higher-order spin chain model with NNNN interactions as described in Section 4.5, providing numerical lower and upper bounds on the energy and visualizing the stability regions in parameter space.
- Produces the **17 figures** included in the thesis, for illustrating convergence properties, energy profiles, and spin configurations.

All computations use Python (NumPy, SciPy) and Matplotlib, and the code is designed to verify, illustrate, and deepen the theoretical analysis of Gamma-convergence for frustrated spin chains under different regimes, bridging rigorous proofs with explicit numerical experiments.
"""

import spins as sp
import visualize as v
import extended_model as ext_mod

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.patches as mpatches

import time
import os
from tqdm import tqdm

DATA = "./data/"
OUTPUT = "./output/"
EXISTING_DATA_MESSAGE = "Existing data not overwritten. Continue..."

LATTICE_SIZE = "Lattice size (n)"
UPPER_RIGHT = "upper right"

### plot style
plt.rcParams.update({
    'font.size': 15,
    
    'legend.fontsize': 13,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    
    'font.family': 'serif',
    'font.serif': ['STIXGeneral'],
    'mathtext.fontset': 'stix',
})

def plot_magnets():
    introduction_example = v.visualize_magnets()
    introduction_example.savefig(OUTPUT + "magnets.png")


def plot_minimizing_configuration_example(alpha, lattice_size=5):
    optimal_spins_visualization = v.visualize_optimal_spins(alpha, lattice_size)
    optimal_spins_visualization.savefig(OUTPUT + f"minimal_spins_{lattice_size}.png")


def plot_limit_energy_alpha_dependency():
    minimal_energy_alpha_dependency = v.visualize_minimal_energy_alpha_dependency()
    minimal_energy_alpha_dependency.savefig(
        OUTPUT + "minimal_energy_alpha_dependency.png"
    )


def minimize_energy(initializer, alpha, start, end):
    filename = f"minimized_energy_{initializer}_{start}_{end}.npz"
    if os.path.exists(DATA + filename):
        answer = (
            input(
                f"Data file already exists at '{DATA + filename}'. Overwrite? (y/n): "
            )
            .strip()
            .lower()
        )
        if answer != "y":
            print(EXISTING_DATA_MESSAGE)
            return
    else:
        print(f"No existing data {filename} found. Proceeding {initializer}...")
    u_ns = []
    minimized_u_n = []
    minimized_E_n = []
    for n in tqdm(range(start, end), desc="minimizing E_n"):
        if initializer == "random":
            u_n = sp.generate_random_spins(n)
        elif initializer == "perturbed":
            u_n = sp.get_minimal_spins_perturbed(alpha, n, eps=2)
        elif initializer == "optimal":
            u_n = sp.get_minimal_spins(alpha, n, "counterclockwise")
        else:
            print(f"Invalid path: {initializer}.")
            return

        res = sp.optimize_energy(u_n, alpha, n)

        u_ns.append(u_n)
        minimized_u_n.append(res.x)
        minimized_E_n.append(res.fun)

    np.savez(
        DATA + filename,
        u_ns=np.array(u_ns, dtype=object),
        minimized_u_n=np.array(minimized_u_n, dtype=object),
        minimized_E_n=minimized_E_n,
        alpha=alpha,
        start=start,
        end=end,
    )


def plot_minimize_energy(initializer: str, start, end):
    filename = f"minimized_energy_{initializer}_{start}_{end}"
    data = np.load(DATA + filename + ".npz", allow_pickle=True)
    alpha = data["alpha"].item()
    start_data = data["start"].item()
    end_data = data["end"].item()
    if start_data > start or end_data < end:
        print("Snippet does not exist")
        exit(0)
    minimized_E_n = data["minimized_E_n"][start - start_data : end - start_data]

    min_E = [sp.get_minimal_energy_n_dependence(alpha, 0) for _ in range(start, end)]
    min_E_n = [sp.get_minimal_energy_n_dependence(alpha, n) for n in range(start, end)]
    minimized_energy_convergence = v.visualize_minimized_energy_convergence(
        minimized_E_n,
        min_E_n,
        min_E,
        alpha,
        start,
        end,
    )
    minimized_energy_convergence.savefig(OUTPUT + filename + ".png")


def spin_chain_minimization(path, alpha, lattice_size, eps):
    filename = f"{path}_n_{lattice_size}_alpha_{int(alpha)}.npz"
    if os.path.exists(DATA + filename):
        answer = (
            input(
                f"Data file already exists at '{DATA + filename}'. Overwrite? (y/n): "
            )
            .strip()
            .lower()
        )
        if answer != "y":
            print(EXISTING_DATA_MESSAGE)
            return
    else:
        print(f"No existing data {filename} found. Proceeding {path}...")

    u_random = sp.generate_random_spins(lattice_size)
    res_random = sp.optimize_energy(u_random, alpha, lattice_size)
    u_random_min = res_random.x

    u_perturbed = sp.get_minimal_spins_perturbed(alpha, lattice_size, eps=eps)
    res_perturbed = sp.optimize_energy(u_perturbed, alpha, lattice_size)
    u_perturbed_min = res_perturbed.x

    np.savez(
        DATA + filename,
        u_random=np.array(u_random, dtype=np.float64),
        u_random_min=np.array(u_random_min, dtype=np.float64),
        u_perturbed=np.array(u_perturbed, dtype=np.float64),
        u_perturbed_min=np.array(u_perturbed_min, dtype=np.float64),
        alpha=alpha,
        lattice_size=lattice_size,
        eps=eps,
    )


def plot_spin_chains(path, alpha, lattice_size):
    data = np.load(
        DATA + f"{path}_n_{lattice_size}_alpha_{int(alpha)}.npz", allow_pickle=True
    )
    u_random = data["u_random"]
    u_random_min = data["u_random_min"]
    u_perturbed = data["u_perturbed"]
    u_perturbed_min = data["u_perturbed_min"]
    alpha = data["alpha"].item()
    eps = data["eps"].item()

    E_random = round(sp.compute_energy(u_random, alpha, lattice_size), 4)
    min_E_random = round(sp.compute_energy(u_random_min, alpha, lattice_size), 4)
    E_perturbed = round(sp.compute_energy(u_perturbed, alpha, lattice_size), 4)
    min_E_perturbed = round(sp.compute_energy(u_perturbed_min, alpha, lattice_size), 4)

    minimizer_spins = v.visualize_spin_minimization_process(
        u_random, u_random_min, alpha, lattice_size, E_random, min_E_random, "random"
    )
    minimizer_spins.savefig(
        OUTPUT + f"minimizer_spin_random_n_{lattice_size}_alpha_{int(alpha)}.png"
    )

    if alpha > 4:
        return

    minimizer_spins = v.visualize_spin_minimization_process(
        u_perturbed,
        u_perturbed_min,
        alpha,
        lattice_size,
        E_perturbed,
        min_E_perturbed,
        "perturbed",
        eps=eps,
    )
    minimizer_spins.savefig(
        OUTPUT + f"minimizer_spin_perturbed_n_{lattice_size}_alpha_{int(alpha)}.png"
    )

    spin_chirality = v.visualize_chirality(
        u_random_min,
        u_perturbed_min,
        min_E_random,
        min_E_perturbed,
        alpha,
        lattice_size,
        eps=eps,
    )
    spin_chirality.savefig(
        OUTPUT + f"chirality_n_{lattice_size}_alpha_{int(alpha)}.png"
    )


def compute_f_hom(alpha, k=100, partition_size=30):
    filename = f"f_hom_k_{k}_alpha_{int(alpha)}_p_{partition_size}.npz"
    if os.path.exists(DATA + filename):
        answer = (
            input(
                f"Data file already exists at '{DATA + filename}'. Overwrite? (y/n): "
            )
            .strip()
            .lower()
        )
        if answer != "y":
            print(EXISTING_DATA_MESSAGE)
            return
    else:
        print(f"No existing data {filename} found. Proceeding {initializer}...")
    if not (0 < alpha <= 4):
        print("This inequality is for alpha in (0, 4]. Continue Code...")
        return

    I_partition = np.linspace(0, 1, partition_size)[1:-1]
    f_hom = []

    for x in tqdm(I_partition, desc="computing f_hom"):
        z = np.array([x / np.sqrt(2), x / np.sqrt(2)])
        candidates = []

        for _ in range(5):
            u_initial = np.random.rand(k + 1) * 2 * np.pi
            res = sp.minimize_f_hom(u_initial, z, alpha, k)
            candidates.append(res.fun / k)

        u_initial = sp.get_minimal_spins(alpha, k)
        res = sp.minimize_f_hom(u_initial, z, alpha, k)
        candidates.append(res.fun / k)

        print(f"candidates: {candidates}")
        best_candidate = min(candidates)
        f_hom.append(best_candidate)

    np.savez(
        DATA + filename,
        f_hom=np.array(f_hom, dtype=np.float64),
        I_partition=np.array(I_partition, dtype=np.float64),
        alpha=alpha,
        k=k,
        partition_size=partition_size,
    )


def plot_f_hom(alpha, k=100, partition_size=20):
    data = np.load(
        DATA + f"f_hom_k_{k}_alpha_{int(alpha)}_p_{partition_size}.npz",
        allow_pickle=True,
    )
    f_hom = data["f_hom"]
    I_partition = data["I_partition"]

    c1 = (alpha - 4) ** 2 / 8.0
    c2 = -(1 + alpha**2 / 8.0)

    f_lower_bound = c1 * I_partition**2 + c2
    f_upper_bound = c1 * I_partition + c2

    plt.figure(figsize=(10, 6))
    plt.plot([], [], " ", label=rf"$\alpha = {alpha}$")
    plt.plot(
        I_partition,
        f_hom,
        label=r"Numerical $f_{hom}(z)$",
        linestyle="-",
        color="blue",
        zorder=5,
    )
    plt.plot(
        I_partition, f_upper_bound, label=r"Upper Bound", linestyle="--", color="green"
    )
    plt.plot(
        I_partition, f_lower_bound, label=r"Lower Bound", linestyle="--", color="red"
    )

    plt.xlabel(r"$|z|$")
    plt.ylabel(r"$f_{hom}(z)$")
    plt.legend()
    plt.savefig(OUTPUT + f"f_hom_k_{k}_alpha_{int(alpha)}_p_{partition_size}.png")


def plot_infimal_energy_bounds_extended_model(alpha1, alpha2, start, end):
    upper_bound = [
        ext_mod.get_infimal_energy_bounds(alpha1, alpha2, n, "upper")
        for n in range(start, end)
    ]
    asymptotic_bound = [
        ext_mod.get_infimal_energy_bounds(alpha1, alpha2, 0, "asymptotic")
        for _ in range(start, end)
    ]
    lower_bound = [
        ext_mod.get_infimal_energy_bounds(alpha1, alpha2, n, "lower")
        for n in range(start, end)
    ]
    infimal_energy_bounds = (
        v.visualize_infimal_energy_bounds_convergence_extended_model(
            first_plot=upper_bound,
            second_plot=asymptotic_bound,
            third_plot=lower_bound,
            alpha1=alpha1,
            alpha2=alpha2,
            start=start,
            end=end,
        )
    )
    infimal_energy_bounds.savefig(
        OUTPUT + EXT_MODEL + "_infimal_energy_bounds" + ".png"
    )


def minimize_energy_extended_model(initializer, alpha1, alpha2, start, end):
    filename = EXT_MODEL + f"_minimized_energy_{initializer}_{start}_{end}.npz"
    if os.path.exists(DATA + filename):
        answer = (
            input(
                f"Data file already exists at '{DATA + filename}'. Overwrite? (y/n): "
            )
            .strip()
            .lower()
        )
        if answer != "y":
            print(EXISTING_DATA_MESSAGE)
            return
    else:
        print(f"No existing data {filename} found. Proceeding {initializer}...")
    u_vals = []
    u_min_vals = []
    min_E_vals = []
    for n in tqdm(range(start, end), desc="minimizing E_n"):
        if initializer == "random":
            u = sp.generate_random_spins(n)
        else:
            print(f"Invalid path: {initializer}.")
            return

        res = ext_mod.optimize_energy_extended_model(u, alpha1, alpha2, n)

        u_vals.append(u)
        u_min_vals.append(res.x)
        min_E_vals.append(res.fun)

    np.savez(
        DATA + filename,
        u_vals=np.array(u_vals, dtype=object),
        u_min_vals=np.array(u_min_vals, dtype=object),
        min_E_vals=min_E_vals,
        alpha1=alpha1,
        alpha2=alpha2,
        start=start,
        end=end,
    )


def plot_minimize_energy_extended_model(initializer, alpha1, alpha2, start, end):
    filename = EXT_MODEL + f"_minimized_energy_{initializer}_{start}_{end}"
    if initializer == "random":
        first_label = r"Approximated $\inf E_n$"
        data = np.load(DATA + filename + ".npz", allow_pickle=True)
        # check if snippet exist
        data_start = data["start"].item()
        data_end = data["end"].item()
        if data_start > start or data_end < end:
            print(f"Snippet of {filename} does not exist")
            exit(0)
        # extract data
        min_E_vals = data["min_E_vals"][start - data_start : end - data_start]
    elif initializer == "ferromagnetic":
        first_label = r"$E^+_{n,F}$"
        min_E_vals = [(-alpha1 + alpha2 + 1) * (1 - 2 / n) for n in range(start, end)]

    # get reference plots
    upper_bound = [
        ext_mod.get_infimal_energy_bounds(alpha1, alpha2, n, "upper")
        for n in range(start, end)
    ]
    lower_bound = [
        ext_mod.get_infimal_energy_bounds(alpha1, alpha2, n, "lower")
        for n in range(start, end)
    ]
    minimized_energy_convergence_extended_model = (
        v.visualize_minimized_energy_convergence_extended_model(
            first_plot=min_E_vals,
            second_plot=upper_bound,
            third_plot=lower_bound,
            alpha1=alpha1,
            alpha2=alpha2,
            start=start,
            end=end,
            first_label=first_label,
            second_label=r"Upper bound on $\inf E_n$",
            third_label=r"Lower bound on $\inf E_n$",
        )
    )
    minimized_energy_convergence_extended_model.savefig(OUTPUT + filename + ".png")


def plot_stability_regions_extended_model(model):
    plt.figure(figsize=(10, 7))
    plt.xlabel(r"$\alpha_1$")
    plt.ylabel(r"$\alpha_2$")
    plt.grid(True, linestyle="--", alpha=0.4)

    a1 = np.linspace(0, 20, 300)
    a2 = np.linspace(0, 3, 300)
    A1, A2 = np.meshgrid(a1, a2)

    if model == "plus":
        sign = "+"
        F_mask = A1 >= 4 * A2 + 9
        AF_mask = A1 <= -4 * A2 + 9
        F_line = 4 * A2 + 9
        AF_line = -4 * A2 + 9

    elif model == "minus":
        sign = "-"
        F_mask = A1 >= 4 * A2 - 9
        AF_mask = A1 <= -4 * A2 - 9
        F_line = 4 * A2 - 9
        AF_line = -4 * A2 - 9
    else:
        print(f"Invalid case {model}. Abort...")
        return

    plt.contourf(A1, A2, F_mask, levels=[0.5, 1.5], colors=["green"], alpha=0.6)
    plt.contourf(A1, A2, AF_mask, levels=[0.5, 1.5], colors=["blue"], alpha=0.6)

    plt.plot(F_line, a2, "g--", lw=2)
    plt.plot(AF_line, a2, "k--", lw=2)

    ax = plt.gca()

    patches = [
        mpatches.Patch(color="green", alpha=0.6, label="Ferromagnetic-stable region"),
        mpatches.Patch(
            color="blue", alpha=0.6, label="Antiferromagnetic-stable region"
        ),
    ]
    reg_legend = ax.legend(handles=patches, loc="upper left")
    ax.add_artist(reg_legend)

    leg_lines = [
        Line2D(
            [],
            [],
            ls="--",
            color="g",
            label=rf"Ferromagnetic boundary  ($\alpha_1=4\alpha_2{sign}9$)",
        ),
        Line2D(
            [],
            [],
            ls="--",
            color="k",
            label=rf"Antiferromagnetic boundary ($\alpha_1=-4\alpha_2{sign}9$)",
        ),
    ]
    ax.legend(handles=leg_lines, loc="lower right")

    plt.xlim(0, 20)
    plt.ylim(0, 3)
    plt.tight_layout()
    plt.savefig(OUTPUT + EXT_MODEL + f"_stability_regions_{model}.png")


def spin_chain_minimization_extended_model(path, alpha1, alpha2, lattice_size):
    filename = (
        EXT_MODEL
        + f"_{path}_n_{lattice_size}_alpha1_{int(alpha1)}_alpha2_{int(alpha2)}.npz"
    )
    if os.path.exists(DATA + filename):
        answer = (
            input(
                f"Data file already exists at '{DATA + filename}'. Overwrite? (y/n): "
            )
            .strip()
            .lower()
        )
        if answer != "y":
            print(EXISTING_DATA_MESSAGE)
            return
    else:
        print(f"No existing data {filename} found. Proceeding {path}...")

    u_random = sp.generate_random_spins(lattice_size)
    res = ext_mod.optimize_energy_extended_model(u_random, alpha1, alpha2, lattice_size)
    u_random_min = res.x

    np.savez(
        DATA + filename,
        u_random=np.array(u_random, dtype=np.float64),
        u_random_min=np.array(u_random_min, dtype=np.float64),
        alpha1=alpha1,
        alpha2=alpha2,
        lattice_size=lattice_size,
    )


def plot_spin_chains_extended_model(path, alpha1, alpha2, lattice_size):
    filename = (
        EXT_MODEL
        + f"_{path}_n_{lattice_size}_alpha1_{int(alpha1)}_alpha2_{int(alpha2)}"
    )
    data = np.load(DATA + filename + ".npz", allow_pickle=True)
    if alpha1 != data["alpha1"].item() and alpha2 != data["alpha2"].item():
        print(f"Data not available for alpha1 = {alpha1} and alpha2 = {alpha2}")
        return
    u_random = data["u_random"]
    u_random_min = data["u_random_min"]

    E_random = round(
        ext_mod.compute_energy_extended_model(u_random, alpha1, alpha2, lattice_size), 5
    )
    min_E_random = round(
        ext_mod.compute_energy_extended_model(
            u_random_min, alpha1, alpha2, lattice_size
        ),
        5,
    )

    minimizer_spins = v.visualize_spin_minimization_process_extended_model(
        u_init=u_random,
        u_min=u_random_min,
        alpha1=alpha1,
        alpha2=alpha2,
        lattice_size=lattice_size,
        E=E_random,
        min_E=min_E_random,
    )
    minimizer_spins.savefig(OUTPUT + filename + ".png")


if __name__ == "__main__":
    RUN_COMPUTATION = False
    RUN_PLOT = True
    EXT_MODEL = "extended_model"
    #################### input parameters ####################
    alpha = 3.0
    lattice_size = 50
    start_of_iteration = 1
    end_of_iteration = 200
    eps = 3.0
    partition_size = 50
    k = 300
    ##################### track runtime #####################
    start_time = time.time()
    ################## Images for Illustration Example 4.3 and 4.5 #######################
    if RUN_PLOT:
        ### Introduction
        plot_magnets()
        ### Example 4.3
        plot_minimizing_configuration_example(alpha=1.24, lattice_size=5)
        ### Example 4.5
        plot_limit_energy_alpha_dependency()

    ##############################################################
    ################### F-AF Spin Chain Model ####################
    ##############################################################

    ################### plot asymptotic behavior of \min E_n ####################
    if RUN_PLOT:
        plot_minimize_energy(initializer="random", start=1, end=200)
        plot_minimize_energy(initializer="perturbed", start=1, end=200)
        plot_minimize_energy(initializer="optimal", start=1, end=200)

    ################## plot spin behavior of u^min_50 ####################
    if RUN_PLOT:
        data_path = "spin_chain_minimization"
        plot_spin_chains(data_path + "_helimagnet", alpha=3.0, lattice_size=50)
        plot_spin_chains(data_path + "_ferromagnet", alpha=5.0, lattice_size=50)

    if RUN_PLOT:
        plot_f_hom(alpha=3.0, k=300, partition_size=50)

    ################### compute asymptotic behavior of \min E_n ####################
    if RUN_COMPUTATION:
        initializer = "random"  # random, perturbed, optimal
        minimize_energy(initializer, alpha, start_of_iteration, end_of_iteration)
        plot_minimize_energy(
            initializer=initializer,
            start=start_of_iteration,
            end=end_of_iteration,
        )

    ################## compute spin behavior ####################
    if RUN_COMPUTATION:
        regime = "helimagnet"
        spin_chain_minimization(
            "spin_chain_minimization_" + regime, alpha, lattice_size, eps
        )
        plot_spin_chains("spin_chain_minimization", alpha, lattice_size)

    ################## energy density f_hom ####################
    if RUN_COMPUTATION:
        compute_f_hom(alpha, k, partition_size)
        plot_f_hom(alpha, k, partition_size)

    ##############################################################
    ################### Extended Spin Chain Model ####################
    ##############################################################

    ##################### asymptotic behavior of E_n extended ####################
    if RUN_PLOT:
        plot_infimal_energy_bounds_extended_model(
            alpha1=2.0, alpha2=0.3, start=6, end=1000
        )

    if RUN_COMPUTATION:
        minimize_energy_extended_model(
            initializer="random", alpha1=2.0, alpha2=0.3, start=5, end=200
        )
    if RUN_PLOT:
        plot_minimize_energy_extended_model(
            initializer="random", alpha1=2, alpha2=0.3, start=5, end=200
        )

    if RUN_PLOT:
        plot_stability_regions_extended_model("plus")
        plot_stability_regions_extended_model("minus")

    if RUN_PLOT:
        plot_minimize_energy_extended_model(
            initializer="ferromagnetic", alpha1=10, alpha2=0.1, start=5, end=200
        )

    ################## spin behavior extended ####################
    if RUN_COMPUTATION:
        spin_chain_minimization_extended_model(
            "spin_chain_minimization_ferromagnet",
            alpha1=10.0,
            alpha2=0.1,
            lattice_size=50,
        )
    if RUN_PLOT:
        plot_spin_chains_extended_model(
            "spin_chain_minimization_ferromagnet",
            alpha1=10.0,
            alpha2=0.1,
            lattice_size=50,
        )

    #################### track runtime ####################
    end_time = time.time()
    print(f"Elapsed time: {end_time - start_time:.4f} seconds")
