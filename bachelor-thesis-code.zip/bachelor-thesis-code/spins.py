"""
- Provides utilities for spin chain generation (optimal, perturbed, random).
- Computes energy and gradient for spin configurations.
- Calculates chirality for domain wall analysis.
- Provides analytical formulas for minimal energies.
- Supports f_hom minimization under constraints.
"""

from typing import Any
import numpy as np
from scipy.optimize import minimize


def get_minimal_spins(
    alpha, n, chirality: str = "counterclockwise"
) -> np.ndarray[Any, np.dtype[np.floating[Any]]]:
    if alpha <= 4:
        phi = np.arccos(alpha / 4)
        if chirality == "counterclockwise":
            return np.arange(n + 1) * phi
        elif chirality == "clockwise":
            return np.arange(n + 1) * (-phi)
        else:
            print("Undefinded Chirality. Abort.")
            return exit(0)
    elif alpha > 4:
        return np.full(n + 1, np.pi / 2)


def get_minimal_spins_perturbed(
    alpha, n, chirality: str = "counterclockwise", eps=0.1
) -> np.ndarray[Any, np.dtype[np.floating[Any]]]:
    rng = np.random.default_rng(12345)
    eps_vec = eps * rng.random(size=n + 1)
    u_perturbed = get_minimal_spins(alpha, n, chirality)
    return u_perturbed + eps_vec


def generate_random_spins(
    n: int, include_boundary_condition=False
) -> np.ndarray[Any, np.dtype[np.floating[Any]]]:
    seed = 12345
    rng = np.random.default_rng(seed)

    if include_boundary_condition:
        u = rng.uniform(low=0, high=2 * np.pi, size=n)
        u_n = (np.arccos(np.cos(u[0] - u[1])) + u[n - 1]) % (2 * np.pi)
        u = np.concatenate([u, [u_n]])
    else:
        u = rng.uniform(low=0, high=2 * np.pi, size=n + 1)
    return u


def chirality(theta1, theta2):
    """
    +1 if theta2 is CCW (positive Chirality) theta1,
    -1 if theta2 is CW  (negative Chirality) theta1,
     0 if they are equal.
    """
    return np.sign(np.sin((theta2 - theta1)))


def compute_energy(
    u: np.ndarray[Any, np.dtype[np.floating[Any]]], alpha: float, n: int
) -> float:
    energy = 0
    angle_difference1 = u - np.roll(u, -1)
    angle_difference2 = u - np.roll(u, -2)
    energy1 = -alpha * np.cos(angle_difference1[: n - 1])
    energy2 = np.cos(angle_difference2[: n - 1])
    energy = energy1.sum() + energy2.sum()
    energy /= n
    return energy


def periodic_boundary_condition(u):
    n = len(u) - 1
    dot_first = np.cos(u[1] - u[0])
    dot_last = np.cos(u[n] - u[n - 1])
    return dot_first - dot_last


def compute_energy_gradient(
    u: np.ndarray[Any, np.dtype[np.floating[Any]]], alpha: float, n: int
) -> np.ndarray[Any, Any]:
    energy_gradient = np.zeros_like(u)
    dif1 = u[: n - 1] - u[1:n]
    dif2 = u[: n - 1] - u[2:]
    energy_gradient[: n - 1] += alpha * np.sin(dif1)
    energy_gradient[1:n] -= alpha * np.sin(dif1)
    energy_gradient[: n - 1] -= np.sin(dif2)
    energy_gradient[2:] += np.sin(dif2)
    energy_gradient /= n
    return energy_gradient


def optimize_energy(
    u: np.ndarray[Any, np.dtype[np.floating[Any]]],
    alpha: float,
    n: int,
    maxiter=10000,
    tolerance=1e-8,
) -> Any:
    constraint = {
        "type": "eq",
        "fun": lambda u: periodic_boundary_condition(u),
    }

    res = minimize(
        fun=compute_energy,
        x0=u,
        args=(alpha, n),
        method="SLSQP",
        jac=compute_energy_gradient,
        constraints=[constraint],
        options={"maxiter": maxiter, "ftol": tolerance},
    )

    # Warning if optimization might not have truly converged
    if not res.success or np.linalg.norm(res.jac) > 1e-6:
        print(
            f"Warning: E_{n} may not be a true minimum. Gradient norm = {np.linalg.norm(res.jac):.2e}"
        )
        print(f"Number of iterations = {res.nit}")
        print(f"Solver message: {res.message}")
    return res


def get_minimal_energy_n_dependence(alpha: float, n: int) -> float:
    if 0 < alpha <= 4:
        if n == 0:
            minimal_energy = -(1 + alpha**2 / 8)
        else:
            minimal_energy = -(1 + alpha**2 / 8) * (1 - 1 / n)
    elif alpha > 4:
        if n == 0:
            minimal_energy = -(alpha - 1)
        else:
            minimal_energy = -(alpha - 1) * (1 - 1 / n)
    else:
        print(f"Alpha = {alpha} invalid input. Abort.")
        exit()
    return minimal_energy


def get_minimal_energy_alpha_dependence(alpha: float) -> float:
    if alpha < 0:
        print(f"alpha = {alpha} invalid. Interaction parameter must be non-negativ.")
        exit(0)
    elif alpha < 4:
        return -(1 + alpha**2 / 8)
    else:
        return -(alpha - 1)


def f_hom_energy(u, alpha, n):
    angle_difference1 = u[:-2] - u[1:-1]
    angle_difference2 = u[:-2] - u[2:]
    energy1 = -alpha * np.cos(angle_difference1)
    energy2 = np.cos(angle_difference2)
    energy = energy1.sum() + energy2.sum()
    return energy


def f_hom_boundary_condition(u, z, k):
    u = u[1:k]
    x = np.cos(u).sum() / len(u)
    y = np.sin(u).sum() / len(u)
    u_average = np.array([x, y])
    u_z_norm = np.linalg.norm(u_average - z)
    return u_z_norm


def minimize_f_hom(u, z, alpha, k):
    constraint_f_hom = {
        "type": "eq",
        "fun": f_hom_boundary_condition,
        "args": (z, k),
    }
    res = minimize(
        fun=f_hom_energy,
        x0=u,
        args=(alpha, k),
        method="SLSQP",
        constraints=[constraint_f_hom],
        options={"maxiter": 10000, "ftol": 1e-8, "disp": 1 > 0},
    )
    # Warning if optimization might not have truly converged
    if not res.success or np.linalg.norm(res.jac) > 1e-6:
        print(
            f"Warning: f_hom(|{z[0]}|) may not be a true minimum. Gradient norm = {np.linalg.norm(res.jac):.2e}"
        )
        print(f"Number of iterations = {res.nit}")
        print(f"Solver message: {res.message}")
    return res
