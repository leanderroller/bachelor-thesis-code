"""
- Generates all plots used in the thesis.
- Plots convergence of numerical vs theoretical energies.
- Visualizes f_hom and its bounds.
- Plots spin configurations and chirality for different initializations.
- Handles extended model spin chain visualizations and energy convergence plots.
"""


import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.patches import FancyArrow
import numpy as np
import spins as sp
import extended_model as nn


# Set the global font size for all plot elements
import matplotlib.pyplot as plt


LATTICE_SIZE = "Lattice size (n)"
UPPER_RIGHT = "upper right"

### plot style
plt.rcParams.update({
    'font.size': 15,
    
    'legend.fontsize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    
    'font.family': 'serif',
    'font.serif': ['STIXGeneral'],
    'mathtext.fontset': 'stix',
})





def visualize_energy_approximation_error(error, start, end):
    x = np.arange(start, end)
    fig, ax = plt.subplots()
    ax.plot(x, error, label="error min E_n")
    ax.set_xlabel("Iterations")
    plt.legend()
    return fig


def visualize_minimized_energy_convergence(
    minimized_E_n,
    min_E_n,
    min_E,
    alpha,
    start,
    end,
    beta=0,
    l1=r"$\min E_n$ approximated ",
    l2=r"$\min E_n$ theoretical ",
    l3=r"$\min E$",
):
    x = np.arange(start, end)
    fig, ax = plt.subplots()
    if beta > 0:
        ax.plot([], [], " ", label=rf"$\alpha_1 = {alpha}$")
        ax.plot([], [], " ", label=rf"$\alpha_2 = {beta}$")
    else:
        ax.plot([], [], " ", label=rf"$\alpha = {alpha}$")
    ax.plot(x, minimized_E_n, label=l1, color="blue")
    ax.plot(x, min_E_n, label=l2, linestyle="--", color="green")
    ax.plot(x, min_E, label=l3, linestyle=":", color="red")
    ax.set_xlabel(LATTICE_SIZE)
    ax.set_ylabel("Energy")

    lines1, labels1 = ax.get_legend_handles_labels()
    ax.legend(lines1, labels1, loc=UPPER_RIGHT)

    return fig


def visualize_minimized_energy_convergence_extended_model(
    first_plot,
    second_plot,
    third_plot,
    alpha1,
    alpha2,
    start,
    end,
    first_label,
    second_label,
    third_label,
):
    x = np.arange(start, end)
    fig, ax = plt.subplots()
    ax.plot([], [], " ", label=rf"$\alpha_1 = {alpha1}$")
    ax.plot([], [], " ", label=rf"$\alpha_2 = {alpha2}$")

    ax.plot(x, first_plot, label=first_label, color="blue")
    ax.plot(x, second_plot, label=second_label, linestyle="--", color="green")
    ax.plot(x, third_plot, label=third_label, linestyle="--", color="red")
    ax.set_xlabel(LATTICE_SIZE)
    ax.set_ylabel("Energy")

    lines1, labels1 = ax.get_legend_handles_labels()
    ax.legend(lines1, labels1, loc=UPPER_RIGHT)

    return fig


def visualize_infimal_energy_bounds_convergence_extended_model(
    first_plot,
    second_plot,
    third_plot,
    alpha1,
    alpha2,
    start,
    end,
):
    x = np.arange(start, end)
    fig, ax = plt.subplots()

    ax.plot([], [], " ", label=rf"$\alpha_1 = {alpha1}$")
    ax.plot([], [], " ", label=rf"$\alpha_2 = {alpha2}$")

    ax.plot(
        x, first_plot, label=r"Upper bound on $\inf E_n$", linestyle="--", color="green"
    )
    ax.plot(x, second_plot, label="Asymptotic bound", linestyle=":", color="darkorange")
    ax.plot(
        x, third_plot, label=r"Lower bound on $\inf E_n$", linestyle="--", color="red"
    )
    ax.set_xlabel(LATTICE_SIZE)
    ax.set_ylabel("Energy")
    lines1, labels1 = ax.get_legend_handles_labels()
    ax.legend(lines1, labels1, loc=UPPER_RIGHT)

    return fig


def visualize_minimal_energy_alpha_dependency():
    fig, ax = plt.subplots()
    ax.spines["right"].set_color("none")
    ax.spines["top"].set_color("none")
    ax.spines["left"].set_position(("data", 0))
    x1 = np.linspace(0, 4, 200)
    x2 = np.linspace(4, 6, 100)
    y1 = [sp.get_minimal_energy_alpha_dependence(n) for n in x1]
    y2 = [sp.get_minimal_energy_alpha_dependence(n) for n in x2]
    ax.plot(x1, y1, label=r"$\min E$ for $0 < \alpha \leq 4$", color="blue")
    ax.plot(x2, y2, label=r"$\min E$ for $\alpha \geq 4$", color="green")
    ax.set_xlabel(r"Interaction ratio ($\alpha$)")
    ax.set_ylabel(r"Energy")
    ax.set_yticks([-1, -2, -3, -4, -5])
    ax.legend()
    return fig


def visualize_optimal_spins(alpha, n):
    spacing = 2
    fig, ax = plt.subplots(figsize=(10, 3))
    ax.set_xlim(-1, n * spacing + 1)
    ax.set_ylim(-1, 1)

    tick_pos = np.arange(0, (n + 1) * spacing, spacing)
    ax.set_xticks(tick_pos)
    ax.set_xticklabels(range(n + 1))

    ax.yaxis.set_visible(False)
    for side in ["top", "right", "left"]:
        ax.spines[side].set_visible(False)

    if n < 15:
        ax.set_aspect("equal", adjustable="box")

    for i in range(n + 1):
        circle = plt.Circle((i * spacing, 0), 1.0, fill=False, alpha=0.3)
        ax.add_patch(circle)

    arrows = []

    u = sp.get_minimal_spins(alpha, n + 1, "clockwise")

    for i, theta in enumerate(u):
        x0 = i * spacing
        y0 = 0
        dx = np.cos(theta)
        dy = np.sin(theta)
        arrow = FancyArrow(
            x0,
            y0,
            dx,
            dy,
            width=0.02,
            head_width=0.08,
            head_length=0.12,
            length_includes_head=True,
            color="black",
        )
        ax.add_patch(arrow)
        arrows.append(arrow)
    return fig


def draw_spin_chain(ax, thetas, title, lattice_size=10):
    spacing = 1.2
    ax.set_aspect("equal", adjustable="box")
    ax.set_title(title)

    ax.set_xlim(-1, lattice_size * spacing + 1)
    ax.set_ylim(-1.5, 1.5)
    tick_pos = np.arange(0, (lattice_size + 1) * spacing, spacing)
    ax.set_xticks(tick_pos)
    ax.set_xticklabels([])

    ax.yaxis.set_visible(False)
    ax.xaxis.set_visible(False)
    for side in ["top", "right", "left", "bottom"]:
        ax.spines[side].set_visible(False)

    for i in range(lattice_size + 1):
        x_center = i * spacing

        dx, dy = np.cos(thetas[i]), np.sin(thetas[i])

        arrow = FancyArrow(
            x_center,
            0,
            dx,
            dy,
            width=0.03,
            head_width=0.2,
            head_length=0.3,
            length_includes_head=True,
            color="black",
        )
        ax.add_patch(arrow)


def visualize_magnets():
    """
    Creates a single figure with three subplots showing F, AF, and Helimagnetic states.
    """
    lattice_size = 10
    helimagnetic_alpha = 2.35

    thetas_F = np.full(lattice_size + 1, np.pi / 2)

    thetas_AF = (np.arange(lattice_size + 1) % 2 * np.pi) + (np.pi / 2)
    phi_H = -np.arccos(helimagnetic_alpha / 4)
    thetas_H = np.pi + np.arange(lattice_size + 1) * phi_H

    fig, axes = plt.subplots(3, 1, figsize=(12, 7))

    draw_spin_chain(axes[0], thetas_F, "Ferromagnetic State")
    draw_spin_chain(axes[1], thetas_AF, "Antiferromagnetic State")
    draw_spin_chain(axes[2], thetas_H, "Helimagnetic State")

    plt.tight_layout(pad=2.0)
    return fig


def animate_spin_minimization_process(u_optimization_history, alpha, n, interval=1000):
    spacing = 2
    fig, ax = plt.subplots(figsize=(10, 3))
    ax.set_xlim(-1, (n - 1) * spacing + 1)
    ax.set_ylim(-1, 1)
    if n < 15:
        ax.set_aspect("equal", adjustable="box")

    for i in range(n):
        circle = plt.Circle((i * spacing, 0), 1.0, fill=False, alpha=0.3)
        ax.add_patch(circle)

    arrows = []

    def init():
        nonlocal arrows
        for arrow in arrows:
            arrow.remove()
        arrows = []
        return arrows

    def update(k):
        nonlocal arrows
        for arrow in arrows:
            arrow.remove()
        arrows.clear()

        u = u_optimization_history[k] % (2 * np.pi)

        for i, theta in enumerate(u):
            x0 = i * spacing
            y0 = 0
            dx = np.cos(theta)
            dy = np.sin(theta)
            arrow = FancyArrow(
                x0,
                y0,
                dx,
                dy,
                width=0.02,
                head_width=0,
                head_length=0,
                length_includes_head=True,
                color="black",
            )
            ax.add_patch(arrow)
            arrows.append(arrow)
        ax.set_title(
            f"Iter {k + 1}/{len(u_optimization_history)}   |   α = {alpha},  n = {n}"
        )
        return arrows

    plt.tight_layout()

    return FuncAnimation(
        fig,
        update,
        frames=len(u_optimization_history),
        init_func=init,
        interval=interval,
        blit=True,
    )


def visualize_spin_minimization_process(
    u_init,
    u_min,
    alpha,
    lattice_size,
    E,
    min_E,
    u_description,
    eps=0.0,
    optimum="given",
    alpha2=0,
):
    if optimum == "given":
        opt_title = "Optimal Spin Chain"
        u_opt = sp.get_minimal_spins(alpha, lattice_size)
        E_opt = round(sp.get_minimal_energy_n_dependence(alpha, lattice_size), 4)
    elif optimum == "specify":
        opt_title = "Ferromagnetic Spin Chain"
        u_opt = np.full(lattice_size + 1, np.pi / 2)
        E_opt = round(
            nn.compute_energy_extended_model(u_opt, alpha, alpha2, lattice_size), 5
        )

    u_description = u_description[0].upper() + u_description[1:]
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 6), sharex=True)

    visualize_spin_chain(
        title=f"{u_description} Spin Chain",
        axis=ax1,
        x=u_init,
        alpha=alpha,
        n=lattice_size,
        energy=E,
        eps=eps,
    )
    visualize_spin_chain(
        title="Minimized Spin Chain",
        axis=ax2,
        x=u_min,
        alpha=alpha,
        n=lattice_size,
        energy=min_E,
    )
    visualize_spin_chain(
        title=opt_title,
        axis=ax3,
        x=u_opt,
        alpha=alpha,
        n=lattice_size,
        energy=E_opt,
        bottom=True,
    )

    fig.tight_layout(h_pad=1.5)
    return fig


def visualize_spin_chain(
    title,
    axis,
    x,
    alpha,
    n,
    energy,
    eps=0,
    scale=0.5,
    hide_y=True,
    bottom=False,
):
    """Visualize a spin chain given list of angles"""
    if "perturbed" in title.lower():
        axis.set_title(
            rf"{title}    |    $E = {energy}$, $\alpha = {alpha}$, $n = {n}$, $\varepsilon = {eps}$",
        )
    else:
        axis.set_title(
            rf"{title}    |    $E = {energy}$, $\alpha = {alpha}$, $n = {n}$",
        )

    for i, theta in enumerate(x):
        dx, dy = np.cos(theta) * scale, np.sin(theta) * scale
        axis.arrow(
            i,
            0,
            dx,
            dy,
            head_width=0.05,
            head_length=0.1,
            fc="k",
            ec="k",
            linewidth=0.8,
        )

    axis.set_xlim(-0.5, n - 0.5)
    axis.set_ylim(-1.2, 1.2)
    if hide_y:
        axis.yaxis.set_visible(False)
    if bottom:
        axis.set_xlabel(LATTICE_SIZE, fontsize=16)
    else:
        axis.xaxis.set_visible(False)
    for side in ["top", "right", "left"]:
        axis.spines[side].set_visible(False)


def visualize_chirality(
    u_random_min,
    u_perturbed_min,
    min_E_random,
    min_E_perturbed,
    alpha,
    lattice_size,
    eps=0,
):
    u_opt = sp.get_minimal_spins(alpha, lattice_size)
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 6), sharex=True)
    visualize_spin_chain(
        title="Initialized with random spin chain",
        axis=ax1,
        x=u_random_min,
        alpha=alpha,
        n=lattice_size,
        energy=min_E_random,
        hide_y=False,
    )
    visualize_spin_chain(
        title="Initialized with perturbed spin chain",
        axis=ax2,
        x=u_perturbed_min,
        alpha=alpha,
        n=lattice_size,
        energy=min_E_perturbed,
        eps=eps,
        hide_y=False,
    )
    visualize_spin_chain(
        title="Theoretical minimizing spin chain",
        axis=ax3,
        x=u_opt,
        alpha=alpha,
        n=lattice_size,
        energy=round(sp.get_minimal_energy_n_dependence(alpha, lattice_size), 4),
        hide_y=False,
        bottom=True,
    )

    u_random_min_chirality = [
        sp.chirality(u_random_min[i], u_random_min[(i + 1)])
        for i in range(lattice_size)
    ]
    u_perturbed_min_chirality = [
        sp.chirality(u_perturbed_min[i], u_perturbed_min[(i + 1)])
        for i in range(lattice_size)
    ]
    u_opt_chirality = [
        sp.chirality(u_opt[i], u_opt[(i + 1)]) for i in range(lattice_size)
    ]
    offset = -1.05
    for ax, chirality_data in zip(
        [ax1, ax2, ax3],
        [u_random_min_chirality, u_perturbed_min_chirality, u_opt_chirality],
    ):
        values = [offset if c == 1 else offset - 0.5 for c in chirality_data]
        if chirality_data == u_random_min_chirality:
            label = "chirality"
        else:
            label = ""
        ax.step(
            np.arange(lattice_size),
            values,
            color="blue",
            where="mid",
            label=label,
            linewidth=1.2,
        )
        ax.set_ylim(-1.7, 1.2)
        ax.set_yticks([-1.5, -1.05])
        ax.set_yticklabels(["-1", "1"])
        ax.spines["left"].set_visible(True)
        if chirality_data == u_random_min_chirality:
            ax.legend(loc=UPPER_RIGHT)

    ax3.set_xlabel(LATTICE_SIZE)

    plt.tight_layout(h_pad=1.5)
    return fig


def animate_minimization_process(u, u_min, u_history, alpha, n, interval=300):
    scale = 0.3

    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 9))

    ax1.set_title(f"α = {alpha},  n = {n} \nRandom Spin Chain ")
    ax1.set_xlim(-0.5, n - 0.5)
    ax1.set_ylim(-1.1, 1.1)
    ax1.axis("off")
    for i, theta in enumerate(u):
        if i == 0:
            dx, dy = np.cos(theta) * scale, np.sin(theta) * scale
            ax1.arrow(
                0, 0, dx, dy, head_width=0, head_length=0, length_includes_head=True
            )
        dx, dy = np.cos(theta) * scale, np.sin(theta) * scale
        ax1.arrow(i, 0, dx, dy, head_width=0, head_length=0, length_includes_head=True)

    ax3.set_title("Minimizer Spin Chain")
    ax3.set_xlim(-0.5, n - 0.5)
    ax3.set_ylim(-1.1, 1.1)
    ax3.axis("off")
    for i, theta in enumerate(u_min):
        dx, dy = np.cos(theta) * scale, np.sin(theta) * scale
        ax3.arrow(i, 0, dx, dy, head_width=0, head_length=0, length_includes_head=True)

    ax2.set_title("Minimization Process")
    ax2.set_xlim(-0.5, n - 0.5)
    ax2.set_ylim(-1.1, 1.1)
    ax2.axis("off")
    arrows = []

    def init():
        return []

    def update(k):
        nonlocal arrows
        for a in arrows:
            a.remove()
        arrows.clear()
        thetas = u_history[k] % (2 * np.pi)
        for i, theta in enumerate(thetas):
            dx, dy = np.cos(theta) * scale, np.sin(theta) * scale
            arrow = FancyArrow(
                i,
                0,
                dx,
                dy,
                width=0.02,
                head_width=0,
                head_length=0,
                length_includes_head=True,
                color="black",
            )
            ax2.add_patch(arrow)
            arrows.append(arrow)
        ax2.set_title(f"Minimization Process (Iter {k + 1}/{len(u_history)})")
        return arrows

    return FuncAnimation(
        fig, update, frames=len(u_history), init_func=init, interval=interval, blit=True
    )


def visualize_spin_chain_extended_model(
    title,
    axis,
    x,
    alpha1,
    alpha2,
    n,
    energy,
    scale=0.5,
    bottom=False,
):
    """Visualize a spin chain given list of angles"""
    axis.set_title(
        rf"{title}    |    $E = {energy}$, $\alpha_1 = {alpha1}$, $\alpha_2 = {alpha2}$, $n = {n}$",
    )

    for i, theta in enumerate(x):
        dx, dy = np.cos(theta) * scale, np.sin(theta) * scale
        axis.arrow(
            i,
            0,
            dx,
            dy,
            head_width=0.05,
            head_length=0.1,
            fc="k",
            ec="k",
            linewidth=0.8,
        )

    axis.set_xlim(-0.5, n - 0.5)
    axis.set_ylim(-1.2, 1.2)
    axis.yaxis.set_visible(False)
    if bottom:
        axis.set_xlabel(LATTICE_SIZE)
    else:
        axis.xaxis.set_visible(False)
    for side in ["top", "right", "left"]:
        axis.spines[side].set_visible(False)


def visualize_spin_minimization_process_extended_model(
    u_init,
    u_min,
    alpha1,
    alpha2,
    lattice_size,
    E,
    min_E,
):
    u_opt = np.full(lattice_size + 1, np.pi / 2)
    E_opt = round(
        nn.compute_energy_extended_model(u_opt, alpha1, alpha2, lattice_size), 5
    )

    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 6), sharex=True)

    visualize_spin_chain_extended_model(
        title="Random Spin Chain",
        axis=ax1,
        x=u_init,
        alpha1=alpha1,
        alpha2=alpha2,
        n=lattice_size,
        energy=E,
    )
    visualize_spin_chain_extended_model(
        title="Minimized Spin Chain",
        axis=ax2,
        x=u_min,
        alpha1=alpha1,
        alpha2=alpha2,
        n=lattice_size,
        energy=min_E,
    )
    visualize_spin_chain_extended_model(
        title="Ferromagnetic Spin Chain",
        axis=ax3,
        x=u_opt,
        alpha1=alpha1,
        alpha2=alpha2,
        n=lattice_size,
        energy=E_opt,
        bottom=True,
    )

    fig.tight_layout(h_pad=1.5)
    return fig
